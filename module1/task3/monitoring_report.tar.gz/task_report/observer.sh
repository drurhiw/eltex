#!/bin/bash

# Файлы конфигурации и логов
CONFIG_FILE="observer.conf"
LOG_FILE="observer.log"

while IFS= read -r script_name || [ -n "$script_name" ]; do
    [ -z "$script_name" ] && continue
    [[ "$script_name" =~ ^# ]] && continue

    pgrep -f "$script_name" >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        nohup bash "$script_name" >/dev/null 2>&1 &
        
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Перезапущен скрипт: $script_name" >> "$LOG_FILE"
    fi
done < "$CONFIG_FILE"
