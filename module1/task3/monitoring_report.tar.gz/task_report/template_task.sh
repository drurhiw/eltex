#!/bin/bash

script_name=$(basename "$0")
if [ "$script_name" = "template_task.sh" ]; then
	echo "я бригадир, сам не работаю"
	exit 1
fi

log_file="report_${script_name%.*}.log"

echo "[$$] $(date '+%Y-%m-%d %H:%M:%S') Скрипт запущен" >> "$log_file"

wait_seconds=$(( RANDOM % 1771 + 30 ))

start_time=$(date +%s)

sleep "$wait_seconds"

end_time=$(date +%s)
actual_time=$(( end_time - start_time ))

echo "[$$] $(date '+%Y-%m-%d %H:%M:%S') Скрипт завершился, работал $actual_time секунд" >> "$log_file"
